﻿namespace EFDBF
{
    internal class EmployeeManagementContext : IDisposable
    {
        internal void SaveChanges()
        {
            throw new NotImplementedException();
        }
    }
}